gzip js file
